import numpy as np
import os
import sys
import shutil

# Cấu hình console để hỗ trợ UTF-8
sys.stdout.reconfigure(encoding='utf-8')

def embed_message(dct_frame, message_bits, delta=2.0):
    """Nhúng tin bằng QIM vào hệ số DCT."""
    h, w = dct_frame.shape
    bit_idx = 0
    dct_stego = dct_frame.copy()
    
    for i in range(0, h, 8):
        for j in range(0, w, 8):
            if bit_idx >= len(message_bits):
                break
            # Nhúng vào hệ số DCT tần số thấp (vị trí [0,0] trong khối 8x8)
            coeff = dct_stego[i, j]
            bit = message_bits[bit_idx]
            if bit == 1:
                dct_stego[i, j] = np.floor(coeff / delta) * delta + delta / 2
            else:
                dct_stego[i, j] = np.floor(coeff / delta) * delta
            bit_idx += 1
    
    return dct_stego, bit_idx

def embed_stego(dct_dir, message_file, output_dir):
    """Nhúng tin từ message.txt vào khung chuyển cảnh bằng QIM."""
    os.makedirs(output_dir, exist_ok=True)
    
    # Đọc khung chuyển cảnh từ step2.py
    try:
        scene_changes = np.load(f'{dct_dir}/scene_changes.npy')
    except FileNotFoundError:
        print("Không tìm thấy file scene_changes.npy. Vui lòng chạy step2.py trước.")
        return []
    
    if len(scene_changes) == 0:
        print("Không có khung chuyển cảnh nào được chọn.")
        return []
    
    scene_change_frame = scene_changes[0]
    print(f"Khung chuyển cảnh được chọn: {scene_change_frame} (f_{scene_change_frame})")

    # Đọc tin nhắn từ message.txt
    try:
        with open(message_file, 'r', encoding='utf-8') as f:
            message = f.read()
    except FileNotFoundError:
        print(f"Không tìm thấy file: {message_file}")
        return []
    
    message_bits = [int(b) for c in message for b in bin(ord(c))[2:].zfill(8)]
    print(f"Tổng số bit tin nhúng: {len(message_bits)}")

    # Đọc danh sách file DCT
    dct_files = sorted([f for f in os.listdir(dct_dir) if f.endswith('.npy') and f != 'scene_changes.npy'])
    total_files = len(dct_files)
    print(f"Tổng số file DCT để xử lý: {total_files}")

    # Sao chép scene_changes.npy sang output_dir
    shutil.copy(f'{dct_dir}/scene_changes.npy', f'{output_dir}/scene_changes.npy')

    frames_used = []
    for idx, frame_file in enumerate(dct_files):
        dct_frame = np.load(f'{dct_dir}/{frame_file}')
        
        if idx == scene_change_frame:
            # Nhúng tin vào khung chuyển cảnh
            dct_stego, bits_embedded = embed_message(dct_frame, message_bits, delta=2.0)
            frames_used.append(idx)
            print(f"Đã nhúng {bits_embedded} bit vào khung {idx}")
            np.save(f'{output_dir}/frame_{idx:03d}_dct_stego.npy', dct_stego)
        else:
            # Sao chép file DCT gốc
            np.save(f'{output_dir}/{frame_file}', dct_frame)
        
        if (idx + 1) % 100 == 0:
            print(f"Đã xử lý {idx + 1}/{total_files} file DCT")

    print(f"Completed embedding of the news. The frame used: {frames_used}")
    return frames_used

if __name__ == '__main__':
    dct_dir = 'dct'
    message_file = 'message.txt'
    output_dir = 'stego_dct'
    embed_stego(dct_dir, message_file, output_dir)
