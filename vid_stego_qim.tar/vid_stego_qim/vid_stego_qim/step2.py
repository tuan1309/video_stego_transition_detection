import cv2
import numpy as np
import os

def apply_dct_and_detect_scene_changes(frames_dir, dct_dir, threshold=0.1):
    os.makedirs(dct_dir, exist_ok=True)
    block_size = 8
    frame_files = sorted([f for f in os.listdir(frames_dir) if f.endswith('.png')])
    total_frames = len(frame_files)
    print(f"Total frames to process: {total_frames}")

    # Lưu hệ số DCT
    dct_frames = []
    for idx, frame_file in enumerate(frame_files):
        frame = cv2.imread(f'{frames_dir}/{frame_file}', cv2.IMREAD_GRAYSCALE)
        h, w = frame.shape
        dct_frame = np.zeros((h, w))
        for i in range(0, h-block_size, block_size):
            for j in range(0, w-block_size, block_size):
                block = frame[i:i+block_size, j:j+block_size].astype(float)
                dct_frame[i:i+block_size, j:j+block_size] = cv2.dct(block)
        np.save(f'{dct_dir}/{frame_file.replace(".png", ".npy")}', dct_frame)
        dct_frames.append(dct_frame)
        if (idx + 1) % 100 == 0:
            print(f"Processed {idx + 1}/{total_frames} frames for DCT")

    print("DCT transformation completed")

    # Tìm khung hình có sự khác biệt lớn nhất
    max_diff = -1
    max_diff_frame = None
    diffs = []
    for k in range(len(dct_frames) - 1):
        fk = dct_frames[k]
        fk1 = dct_frames[k + 1]
        diff = np.sum(np.abs(fk - fk1))
        diffs.append(diff)
        if diff > max_diff:
            max_diff = diff
            max_diff_frame = k + 1  # Lưu khung hình tiếp theo (fk1)
        if (k + 1) % 100 == 0:
            print(f"Processed {k + 1}/{len(dct_frames) - 1} frame pairs for scene detection")

    # Lưu khung hình có sự khác biệt lớn nhất
    scene_changes = [max_diff_frame] if max_diff_frame is not None else []
    print(f"Selected frame with maximum difference: {scene_changes}")
    np.save(f'{dct_dir}/scene_changes.npy', np.array(scene_changes))
    return scene_changes

if __name__ == '__main__':
    apply_dct_and_detect_scene_changes('frames', 'dct', threshold=0.1)