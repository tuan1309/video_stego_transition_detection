import cv2
import numpy as np
import pywt
import os
import sys

# Cấu hình console để hỗ trợ UTF-8
sys.stdout.reconfigure(encoding='utf-8')

def reconstruct_frame(frame_gray, dct_stego, beta=0.1):
    """Kết hợp hệ số DWT và DCT nhúng tin, tái tạo khung hình."""
    # Áp dụng DWT cho khung hình gốc
    frame_float = frame_gray.astype(float)
    coeffs = pywt.dwt2(frame_float, 'haar')
    LL, (LH, HL, HH) = coeffs
    
    # Chuẩn hóa DCT để tương thích với DWT
    norm_dct = dct_stego / np.max(np.abs(dct_stego))
    if LL.shape != norm_dct.shape:
        norm_dct = cv2.resize(norm_dct, (LL.shape[1], LL.shape[0]))
    
    # Kết hợp: S(p, q) = (1 - beta) * C(p, q) + beta * R(p, q)
    combined_LL = (1 - beta) * LL + beta * norm_dct
    
    # Tái tạo khung hình bằng IDWT
    coeffs_combined = (combined_LL, (LH, HL, HH))
    frame_reconstructed = pywt.idwt2(coeffs_combined, 'haar')
    
    # Chuyển về uint8
    frame_reconstructed = np.clip(frame_reconstructed, 0, 255).astype(np.uint8)
    return frame_reconstructed

def combine_dwt_dct(frames_dir, stego_dct_dir, stego_dir, output_video, fps=30):
    """Tái tạo khung hình nhúng tin, lưu khung và tạo video."""
    os.makedirs(stego_dir, exist_ok=True)
    frame_files = sorted([f for f in os.listdir(frames_dir) if f.endswith('.png')])
    
    # Đọc scene_changes.npy
    scene_changes_path = f'{stego_dct_dir}/scene_changes.npy'
    if not os.path.exists(scene_changes_path):
        print(f"Không tìm thấy file {scene_changes_path}. Vui lòng kiểm tra step3.py.")
        return
    
    scene_changes = np.load(scene_changes_path)
    scene_change_frame = scene_changes[0] if len(scene_changes) > 0 else None
    
    # Lấy độ phân giải từ khung đầu tiên
    first_frame = cv2.imread(f'{frames_dir}/{frame_files[0]}')
    height, width = first_frame.shape[:2]
    
    # Khởi tạo video writer
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    video_writer = cv2.VideoWriter(output_video, fourcc, fps, (width, height))
    if not video_writer.isOpened():
        print(f"Không thể tạo video {output_video}. Vui lòng kiểm tra codec hoặc đường dẫn.")
        return

    for idx, frame_file in enumerate(frame_files):
        frame = cv2.imread(f'{frames_dir}/{frame_file}', cv2.IMREAD_GRAYSCALE)
        frame_color = cv2.imread(f'{frames_dir}/{frame_file}')
        
        if idx == scene_change_frame:
            # Tái tạo khung chuyển cảnh
            dct_stego = np.load(f'{stego_dct_dir}/frame_{idx:03d}_dct_stego.npy')
            frame_reconstructed = reconstruct_frame(frame, dct_stego, beta=0.1)
            frame_reconstructed_bgr = cv2.cvtColor(frame_reconstructed, cv2.COLOR_GRAY2BGR)
            cv2.imwrite(f'{stego_dir}/{frame_file}', frame_reconstructed_bgr)
            video_writer.write(frame_reconstructed_bgr)
        else:
            # Sao chép khung gốc
            cv2.imwrite(f'{stego_dir}/{frame_file}', frame_color)
            video_writer.write(frame_color)
        
        if (idx + 1) % 100 == 0:
            print(f"Đã xử lý {idx + 1}/{len(frame_files)} khung hình")

    video_writer.release()
    print(f"Completed frame and video reconstruction: {output_video}")

if __name__ == '__main__':
    frames_dir = 'frames'
    stego_dct_dir = 'stego_dct'
    stego_dir = 'stego_frames'
    output_video = 'stego_video.mp4'
    combine_dwt_dct(frames_dir, stego_dct_dir, stego_dir, output_video, fps=30)
