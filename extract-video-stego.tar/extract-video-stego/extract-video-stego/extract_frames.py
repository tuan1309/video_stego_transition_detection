import cv2
import os

def extract_frames(video_path, output_dir):
    vid = cv2.VideoCapture(video_path)
    count = 0
    os.makedirs(output_dir, exist_ok=True)
    while vid.isOpened():
        ret, frame = vid.read()
        if not ret:
            break
        cv2.imwrite(f'{output_dir}/frame_{count:03d}.png', frame)
        count += 1
        if count % 100 == 0:  # In tiến độ mỗi 100 frame
            print(f"Extracted {count} frames...")
    vid.release()
    print(f"Total frames extracted: {count}")

if __name__ == '__main__':
    extract_frames('input_video.mp4', 'frames')
